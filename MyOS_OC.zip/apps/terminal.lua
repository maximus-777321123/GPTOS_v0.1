-- Терминал
while true do io.write("> ") local cmd = io.read() os.execute(cmd) end