# MyOS
Пользовательская ОС для OpenComputers, вдохновлённая Windows.