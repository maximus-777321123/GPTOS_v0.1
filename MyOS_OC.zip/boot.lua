-- Загрузочный файл ОС
print("Загрузка MyOS...")
require("system/main")